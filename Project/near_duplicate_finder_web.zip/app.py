from flask import Flask, render_template, request, jsonify, send_file
from werkzeug.utils import secure_filename
from pathlib import Path
import pandas as pd
import os
import tempfile

from main import (
    NearDuplicateFinder,
    tokenize,
    exact_verify,
    load_dataset,
    build_question_dictionary,
    evaluate_pair_labels,
)

app = Flask(__name__)
BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
RESULT_DIR = BASE_DIR / "results"
UPLOAD_DIR.mkdir(exist_ok=True)
RESULT_DIR.mkdir(exist_ok=True)

ALLOWED_EXTENSIONS = {"csv", "xlsx"}


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def make_finder(k=3, min_common_tokens=3, min_jaccard=0.50):
    return NearDuplicateFinder(
        k=int(k),
        num_hashes=60,
        bands=60,
        rows=1,
        min_common_tokens=int(min_common_tokens),
        min_jaccard=float(min_jaccard),
    )


@app.route("/")
def index():
    return render_template("index.html")


@app.post("/api/compare")
def compare():
    data = request.get_json(silent=True) or {}
    q1 = str(data.get("question1", "")).strip()
    q2 = str(data.get("question2", "")).strip()

    if not q1 or not q2:
        return jsonify({"error": "Please enter both questions."}), 400

    min_common = int(data.get("min_common_tokens", 3))
    min_jaccard = float(data.get("min_jaccard", 0.50))

    t1 = tokenize(q1)
    t2 = tokenize(q2)
    duplicate, lcs, coverage, jac = exact_verify(
        t1, t2, min_common, min_jaccard
    )

    return jsonify({
        "duplicate": bool(duplicate),
        "question1": q1,
        "question2": q2,
        "tokens1": t1,
        "tokens2": t2,
        "jaccard": round(jac, 3),
        "common_substring_tokens": int(lcs),
        "substring_coverage": round(coverage, 3),
    })


@app.post("/api/upload")
def upload():
    if "file" not in request.files:
        return jsonify({"error": "No dataset file selected."}), 400

    file = request.files["file"]
    if not file.filename:
        return jsonify({"error": "Please select a CSV or Excel file."}), 400

    if not allowed_file(file.filename):
        return jsonify({"error": "Only .csv and .xlsx files are supported."}), 400

    filename = secure_filename(file.filename)
    saved_path = UPLOAD_DIR / filename
    file.save(saved_path)

    try:
        df = load_dataset(str(saved_path))
        questions = build_question_dictionary(df)

        k = int(request.form.get("k", 3))
        min_common = int(request.form.get("min_common_tokens", 3))
        min_jaccard = float(request.form.get("min_jaccard", 0.50))

        finder = make_finder(k, min_common, min_jaccard).fit(questions)
        candidates, verified, final = finder.run()
        metrics = evaluate_pair_labels(df, finder)

        verification_path = RESULT_DIR / "verification_results.csv"
        final_path = RESULT_DIR / "final_duplicate_pairs.csv"

        verified.to_csv(verification_path, index=False)
        final.to_csv(final_path, index=False)

        duplicate_rows = []
        if not final.empty:
            for _, row in final.iterrows():
                duplicate_rows.append({
                    "question_1_id": row["question_1_id"],
                    "question_2_id": row["question_2_id"],
                    "question_1": row["question_1"],
                    "question_2": row["question_2"],
                    "jaccard": float(row["jaccard"]),
                    "common_substring_tokens": int(row["common_substring_tokens"]),
                    "substring_coverage": float(row["substring_coverage"]),
                })

        return jsonify({
            "success": True,
            "filename": filename,
            "rows": len(df),
            "questions_processed": len(questions),
            "candidate_pairs": len(candidates),
            "verified_duplicates": len(final),
            "duplicates": duplicate_rows,
            "metrics": metrics,
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.get("/download/<name>")
def download(name):
    allowed = {
        "verification": RESULT_DIR / "verification_results.csv",
        "duplicates": RESULT_DIR / "final_duplicate_pairs.csv",
    }
    path = allowed.get(name)
    if path is None or not path.exists():
        return jsonify({"error": "Result file not found."}), 404
    return send_file(path, as_attachment=True)


if __name__ == "__main__":
    # Website runs at http://127.0.0.1:5000
    app.run(host="127.0.0.1", port=5000, debug=True)

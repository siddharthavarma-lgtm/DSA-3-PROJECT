function esc(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;");
}

async function compareQuestions() {
    const q1 = document.getElementById("question1").value.trim();
    const q2 = document.getElementById("question2").value.trim();
    const box = document.getElementById("compareResult");

    if (!q1 || !q2) {
        box.innerHTML = '<div class="error">Please enter both questions.</div>';
        return;
    }

    box.innerHTML = '<div class="result">Analyzing...</div>';

    try {
        const response = await fetch("/api/compare", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                question1: q1,
                question2: q2,
                min_common_tokens: document.getElementById("minCommon").value,
                min_jaccard: document.getElementById("minJaccard").value
            })
        });

        const data = await response.json();
        if (!response.ok) throw new Error(data.error);

        const cls = data.duplicate ? "duplicate" : "not-duplicate";
        const title = data.duplicate
            ? "✓ Near-Duplicate Questions"
            : "✗ Not a Near-Duplicate Pair";

        box.innerHTML = `
            <div class="result ${cls}">
                <div class="result-title">${title}</div>
                <b>Jaccard Similarity:</b> ${data.jaccard}<br>
                <b>Common Substring Tokens:</b> ${data.common_substring_tokens}<br>
                <b>Substring Coverage:</b> ${data.substring_coverage}<br><br>
                <b>Question 1 Tokens:</b> ${esc(data.tokens1.join(", "))}<br>
                <b>Question 2 Tokens:</b> ${esc(data.tokens2.join(", "))}
            </div>`;
    } catch (err) {
        box.innerHTML = `<div class="error">${esc(err.message)}</div>`;
    }
}

document.getElementById("uploadForm").addEventListener("submit", async (event) => {
    event.preventDefault();

    const file = document.getElementById("file").files[0];
    const status = document.getElementById("uploadStatus");

    if (!file) {
        status.innerHTML = '<div class="error">Please select a dataset.</div>';
        return;
    }

    const formData = new FormData();
    formData.append("file", file);
    formData.append("k", document.getElementById("k").value);
    formData.append("min_common_tokens", document.getElementById("datasetMinCommon").value);
    formData.append("min_jaccard", document.getElementById("datasetMinJaccard").value);

    status.innerHTML = '<div class="result">Processing dataset...</div>';

    try {
        const response = await fetch("/api/upload", {
            method: "POST",
            body: formData
        });

        const data = await response.json();
        if (!response.ok) throw new Error(data.error);

        document.getElementById("dashboard").classList.remove("hidden");
        document.getElementById("rows").textContent = data.rows;
        document.getElementById("questions").textContent = data.questions_processed;
        document.getElementById("candidates").textContent = data.candidate_pairs;
        document.getElementById("duplicatesCount").textContent = data.verified_duplicates;

        const body = document.getElementById("resultsBody");
        body.innerHTML = "";

        if (data.duplicates.length === 0) {
            body.innerHTML = '<tr><td colspan="7">No near-duplicate pairs found.</td></tr>';
        } else {
            data.duplicates.forEach(row => {
                body.innerHTML += `
                    <tr>
                        <td>${esc(row.question_1_id)}</td>
                        <td>${esc(row.question_2_id)}</td>
                        <td>${esc(row.question_1)}</td>
                        <td>${esc(row.question_2)}</td>
                        <td>${row.jaccard}</td>
                        <td>${row.common_substring_tokens}</td>
                        <td>${row.substring_coverage}</td>
                    </tr>`;
            });
        }

        const metrics = document.getElementById("metrics");
        if (data.metrics) {
            metrics.innerHTML = `<div class="metrics-grid">
                ${Object.entries(data.metrics).map(([key, value]) =>
                    `<div class="metric"><span>${esc(key)}</span><b>${esc(value)}</b></div>`
                ).join("")}
            </div>`;
        } else {
            metrics.innerHTML = "<p>No labeled evaluation columns were found in this dataset.</p>";
        }

        status.innerHTML =
            `<div class="success">Dataset processed successfully: ${esc(data.filename)}</div>`;
        window.scrollTo({top: document.getElementById("dashboard").offsetTop - 20, behavior:"smooth"});
    } catch (err) {
        status.innerHTML = `<div class="error">${esc(err.message)}</div>`;
    }
});

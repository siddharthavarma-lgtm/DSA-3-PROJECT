import re
import math
import argparse
from collections import defaultdict
import pandas as pd

# ============================================================
# Near-Duplicate Question Finder
# DSA Project: Shingling -> Double Hashing -> LSH -> Verification
# ============================================================

STOP_WORDS = {
    "a", "an", "the", "is", "are", "am", "was", "were", "be", "been",
    "being", "to", "of", "in", "on", "for", "with", "and", "or", "as",
    "at", "by", "from", "this", "that", "these", "those", "it", "its",
    "i", "we", "you", "he", "she", "they", "my", "your", "our", "their"
}

# Two independent polynomial hash moduli.
MOD1 = 1_000_000_007
MOD2 = 1_000_000_009
BASE1 = 911382323
BASE2 = 972663749


def preprocess(text: str) -> str:
    """Normalize text and remove common stop words."""
    text = str(text).lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    tokens = text.split()
    tokens = [t for t in tokens if t not in STOP_WORDS]
    return " ".join(tokens)


def tokenize(text: str):
    return preprocess(text).split()


def make_shingles(tokens, k=3):
    """Create overlapping token k-grams."""
    if len(tokens) < k:
        return {" ".join(tokens)} if tokens else set()
    return {" ".join(tokens[i:i+k]) for i in range(len(tokens)-k+1)}


def polynomial_hash(text: str, base: int, mod: int) -> int:
    """Polynomial rolling-style hash for a shingle."""
    h = 0
    for ch in text:
        h = (h * base + ord(ch)) % mod
    return h


def double_hash(shingle: str):
    """Return two independent polynomial hash values."""
    return (
        polynomial_hash(shingle, BASE1, MOD1),
        polynomial_hash(shingle, BASE2, MOD2),
    )


def minhash_signature(shingles, num_hashes=60):
    """
    Build a compact MinHash-style signature from double hashes.
    Each hash function is generated from the two base hash values.
    """
    if not shingles:
        return [0] * num_hashes

    signature = [MOD1 - 1] * num_hashes

    for shingle in shingles:
        h1, h2 = double_hash(shingle)
        for i in range(num_hashes):
            # Universal hashing:
            # g_i(x) = (a_i*h1 + b_i*h2 + c_i) mod MOD1
            a = (i * 2 + 1) * 104729 + 17
            b = (i * 3 + 1) * 130363 + 31
            c = i * i + 97
            value = (a * h1 + b * h2 + c) % MOD1
            if value < signature[i]:
                signature[i] = value

    return signature


def lsh_candidates(signatures, bands=60, rows=1):
    """
    LSH banding.
    With 60 signature values, 10 bands x 6 rows are used.
    Questions sharing a band bucket become candidate pairs.
    """
    buckets = defaultdict(list)
    candidates = set()

    total = bands * rows
    if not signatures:
        return set()

    # Use the first 'total' signature values.
    for qid, sig in signatures.items():
        padded = sig + [0] * max(0, total - len(sig))
        for band in range(bands):
            start = band * rows
            band_values = tuple(padded[start:start+rows])
            bucket_key = (band, hash(band_values))
            buckets[bucket_key].append(qid)

    for ids in buckets.values():
        if len(ids) > 1:
            for i in range(len(ids)):
                for j in range(i + 1, len(ids)):
                    candidates.add(tuple(sorted((ids[i], ids[j]))))

    return candidates


def jaccard_similarity(set_a, set_b):
    union = set_a | set_b
    if not union:
        return 0.0
    return len(set_a & set_b) / len(union)


def longest_common_substring_length(tokens_a, tokens_b):
    """
    Exact longest common contiguous token sequence.
    Dynamic programming: O(m*n) time and O(n) space.
    """
    if not tokens_a or not tokens_b:
        return 0

    prev = [0] * (len(tokens_b) + 1)
    best = 0

    for a in tokens_a:
        curr = [0] * (len(tokens_b) + 1)
        for j, b in enumerate(tokens_b, start=1):
            if a == b:
                curr[j] = prev[j - 1] + 1
                best = max(best, curr[j])
        prev = curr

    return best


def exact_verify(tokens_a, tokens_b, min_common_tokens=3, min_jaccard=0.50):
    """
    Verify an LSH candidate using exact common-substring analysis
    and token-set Jaccard similarity.
    """
    lcs_len = longest_common_substring_length(tokens_a, tokens_b)
    jac = jaccard_similarity(set(tokens_a), set(tokens_b))

    min_len = max(1, min(len(tokens_a), len(tokens_b)))
    coverage = lcs_len / min_len

    duplicate = (
        lcs_len >= min_common_tokens and
        (coverage >= 0.50 or jac >= min_jaccard)
    )

    return duplicate, lcs_len, coverage, jac


class NearDuplicateFinder:
    def __init__(self, k=3, num_hashes=60, bands=10, rows=6,
                 min_common_tokens=3, min_jaccard=0.50):
        self.k = k
        self.num_hashes = num_hashes
        self.bands = bands
        self.rows = rows
        self.min_common_tokens = min_common_tokens
        self.min_jaccard = min_jaccard

        self.questions = {}
        self.tokens = {}
        self.shingles = {}
        self.signatures = {}

    def fit(self, questions):
        """
        questions: dict {question_id: question_text}
        """
        self.questions = questions

        for qid, text in questions.items():
            tokens = tokenize(text)
            sh = make_shingles(tokens, self.k)
            self.tokens[qid] = tokens
            self.shingles[qid] = sh
            self.signatures[qid] = minhash_signature(sh, self.num_hashes)

        return self

    def find_candidates(self):
        return lsh_candidates(self.signatures, self.bands, self.rows)

    def verify_candidates(self, candidates):
        results = []

        for q1, q2 in sorted(candidates):
            duplicate, lcs, coverage, jac = exact_verify(
                self.tokens[q1],
                self.tokens[q2],
                self.min_common_tokens,
                self.min_jaccard
            )

            results.append({
                "question_1_id": q1,
                "question_2_id": q2,
                "question_1": self.questions[q1],
                "question_2": self.questions[q2],
                "jaccard": round(jac, 3),
                "common_substring_tokens": lcs,
                "substring_coverage": round(coverage, 3),
                "duplicate": duplicate
            })

        return pd.DataFrame(results)

    def run(self):
        candidates = self.find_candidates()
        verified = self.verify_candidates(candidates)
        if verified.empty:
            final = verified.copy()
        else:
            final = verified[verified["duplicate"]].copy()

        return candidates, verified, final


def load_dataset(path):
    """
    Supports CSV or Excel.
    Required columns: question1/question2 or question.
    """
    if path.lower().endswith(".xlsx"):
        df = pd.read_excel(path)
    else:
        df = pd.read_csv(path)

    return df


def build_question_dictionary(df):
    """
    Convert pair-style dataset to unique question dictionary.
    """
    questions = {}
    next_id = 1

    if "question1" in df.columns and "question2" in df.columns:
        for _, row in df.iterrows():
            q1 = str(row["question1"])
            q2 = str(row["question2"])

            id1 = f"Q{next_id}"
            next_id += 1
            id2 = f"Q{next_id}"
            next_id += 1

            questions[id1] = q1
            questions[id2] = q2

    elif "question" in df.columns:
        for _, row in df.iterrows():
            questions[f"Q{next_id}"] = str(row["question"])
            next_id += 1
    else:
        raise ValueError(
            "Dataset must contain either question1/question2 columns "
            "or a question column."
        )

    return questions


def evaluate_pair_labels(df, finder):
    """
    Evaluate datasets containing:
      question1, question2, is_duplicate
    by directly running the exact verification logic on each pair.
    """
    required = {"question1", "question2", "is_duplicate"}
    if not required.issubset(df.columns):
        return None

    tp = tn = fp = fn = 0

    for _, row in df.iterrows():
        t1 = tokenize(row["question1"])
        t2 = tokenize(row["question2"])

        pred, _, _, _ = exact_verify(
            t1, t2,
            finder.min_common_tokens,
            finder.min_jaccard
        )

        actual = int(row["is_duplicate"]) == 1

        if pred and actual:
            tp += 1
        elif not pred and not actual:
            tn += 1
        elif pred and not actual:
            fp += 1
        else:
            fn += 1

    precision = tp / (tp + fp) if tp + fp else 0
    recall = tp / (tp + fn) if tp + fn else 0
    f1 = (2 * precision * recall / (precision + recall)
          if precision + recall else 0)

    return {
        "TP": tp, "TN": tn, "FP": fp, "FN": fn,
        "Precision": round(precision, 3),
        "Recall": round(recall, 3),
        "F1": round(f1, 3)
    }


def demo():
    """Built-in demonstration for project presentation."""
    questions = {
        "Q1": "How can I learn Python programming?",
        "Q2": "What is the best way to learn Python programming?",
        "Q3": "How do I learn Java programming?",
        "Q4": "What are the best methods for learning Java programming?",
        "Q5": "How can I bake a chocolate cake at home?",
        "Q6": "What is the easiest way to bake a chocolate cake at home?",
        "Q7": "How do I sort an array in Python?",
        "Q8": "What is the method to sort an array in Python?"
    }

    finder = NearDuplicateFinder(
        k=3,
        num_hashes=60,
        bands=60,
        rows=1,
        min_common_tokens=3,
        min_jaccard=0.50
    ).fit(questions)

    candidates, verified, final = finder.run()

    print("\n" + "=" * 70)
    print(" NEAR-DUPLICATE QUESTION FINDER")
    print("=" * 70)

    print("\n1. INPUT QUESTIONS")
    print("-" * 70)
    for qid, q in questions.items():
        print(f"{qid}: {q}")

    print("\n2. PREPROCESSING + k-GRAM SHINGLING")
    print("-" * 70)
    for qid in questions:
        print(f"{qid} tokens  : {finder.tokens[qid]}")
        print(f"{qid} shingles: {list(finder.shingles[qid])[:4]}")

    print("\n3. DOUBLE POLYNOMIAL HASHING")
    print("-" * 70)
    for qid in list(questions)[:3]:
        first_shingle = next(iter(finder.shingles[qid]), "")
        if first_shingle:
            print(f"{qid}: '{first_shingle}' -> {double_hash(first_shingle)}")

    print("\n4. LSH CANDIDATE PAIRS")
    print("-" * 70)
    if candidates:
        for pair in sorted(candidates):
            print(pair)
    else:
        print("No candidate pairs found.")

    print("\n5. EXACT VERIFICATION")
    print("-" * 70)
    if verified.empty:
        print("No candidates to verify.")
    else:
        print(
            verified[
                ["question_1_id", "question_2_id", "jaccard",
                 "common_substring_tokens", "substring_coverage", "duplicate"]
            ].to_string(index=False)
        )

    print("\n6. FINAL NEAR-DUPLICATE PAIRS")
    print("-" * 70)
    if final.empty:
        print("No near-duplicate pairs found.")
    else:
        for _, row in final.iterrows():
            print(f"{row['question_1_id']} <-> {row['question_2_id']}")
            print(f"  Q1: {row['question_1']}")
            print(f"  Q2: {row['question_2']}")
            print(
                f"  Jaccard={row['jaccard']}, "
                f"LCS tokens={row['common_substring_tokens']}, "
                f"Coverage={row['substring_coverage']}"
            )

    print("\n" + "=" * 70)
    print(f"Total questions       : {len(questions)}")
    print(f"LSH candidate pairs   : {len(candidates)}")
    print(f"Verified duplicates   : {len(final)}")
    print("=" * 70)


def main():
    parser = argparse.ArgumentParser(
        description="Near-Duplicate Question Finder using DSA techniques"
    )
    parser.add_argument(
        "--file",
        help="CSV/XLSX dataset. If omitted, the built-in demo runs."
    )
    parser.add_argument(
        "--k", type=int, default=3,
        help="Token shingle size (default: 3)"
    )
    args = parser.parse_args()

    if not args.file:
        demo()
        return

    df = load_dataset(args.file)

    print("\nDataset loaded successfully.")
    print(f"Rows: {len(df)}")
    print(f"Columns: {list(df.columns)}")

    questions = build_question_dictionary(df)

    finder = NearDuplicateFinder(k=args.k, bands=60, rows=1).fit(questions)
    candidates, verified, final = finder.run()

    print("\n========== PROJECT RESULTS ==========")
    print(f"Questions processed : {len(questions)}")
    print(f"LSH candidates      : {len(candidates)}")
    print(f"Final duplicates    : {len(final)}")

    if not final.empty:
        print("\nFinal Near-Duplicate Pairs:")
        print(final[
            ["question_1_id", "question_2_id", "jaccard",
             "common_substring_tokens", "substring_coverage"]
        ].to_string(index=False))

    metrics = evaluate_pair_labels(df, finder)
    if metrics:
        print("\n========== EVALUATION ==========")
        for key, value in metrics.items():
            print(f"{key}: {value}")

    verified.to_csv("verification_results.csv", index=False)
    final.to_csv("final_duplicate_pairs.csv", index=False)

    print("\nOutput files created:")
    print("  verification_results.csv")
    print("  final_duplicate_pairs.csv")


if __name__ == "__main__":
    main()

# Near-Duplicate Question Finder — Web Version

## 1. Open the project in VS Code

Open the `near_duplicate_finder_web` folder.

## 2. Open PowerShell in that folder

```powershell
cd C:\path\to\near_duplicate_finder_web
```

## 3. Create a virtual environment (recommended)

```powershell
python -m venv venv
```

Activate it:

```powershell
.\venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\venv\Scripts\Activate.ps1
```

## 4. Install packages

```powershell
python -m pip install -r requirements.txt
```

## 5. Start the website

```powershell
python app.py
```

You should see Flask start on:

http://127.0.0.1:5000

Open that address in Chrome/Edge.

## Dataset format

Pair dataset:

```text
question1,question2,is_duplicate
How do I learn Python?,What is the best way to learn Python?,1
...
```

Or single-question dataset:

```text
question
How do I learn Python?
What is Java?
...
```

The uploaded algorithm remains in `main.py`; `app.py` provides the website/API layer.
